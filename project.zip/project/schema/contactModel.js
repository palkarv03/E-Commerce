const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");
const config = require("config");

let contactSchema = new mongoose.Schema({
  name: { type: String, required: true, minlength: 3, maxlength: 30 },
  email: { type: String, required: true, minlength: 3, maxlength: 30 },
  message: { type: String, required: true, minlength: 3, maxlength: 30 }
});

let contacts = mongoose.model("contacts", contactSchema);

module.exports = contacts;
