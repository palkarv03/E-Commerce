const jwt = require("jsonwebtoken");
const config = require("config");

function userAuthMidddleware(req, res, next) {
  let token = req.header("x-auth-token");
  if (!token) {
    return res.status(401).send("Access Denied !");
  }
  try {
    let decoded = jwt.verify(token, config.get("usertoken"));
    req.userModel = decoded;
    next();
  } catch (ex) {
    console.log("Invalid Token");
  }
}

module.exports = userAuthMidddleware;
