let express = require("express");
let router = express.Router();
let bcrypt = require("bcrypt");
let U = require("../schema/userModel");

//creating GET api
router.get("/all_User", async (req, res) => {
  let user = await U.userModel.find();
  if (!user) {
    return res.status(403).send("No Users Found !");
  }
  res.send(user);
});

//creating POST api
router.post("/new_User", async (req, res) => {
  let { error } = U.ValidationError(req.body);
  if (error) {
    res.status(403).send(error.details[0].message);
  }
  let email = await U.userModel.findOne({"userLogin.userEmail":req.body.userLogin.userEmail});
  if(!email){
      return res.status(401).send({message:"Email Already Exists !"});
  }

  let data = new U.userModel({
      firstname=req.body.firstname,
      lastname=req.body.lastname,
      newsLetterCheck=req.body.newsLetterCheck,
      userLogin=req.body.userLogin,
      termsAcceptCheck=req.body.termsAcceptCheck,
      resetPasswordToken=req.body.resetPasswordToken,
      resetPasswordExpires=req.body.resetPasswordExpires,
      isAdmin=req.body.isAdmin
  });

  let salt = await bcrypt.genSalt(10);//userPassword Encryption
  data.userLogin.userPassword = await bcrypt.hash(data.userLogin.userPassword, salt);
  let items = data.save();
  let token = items.userValidToken();
  res
  .header("x-auth-token", token)
  .send({
      message:"Registration Successfull !", data: items, token: token
  });
});

module.exports = router;
