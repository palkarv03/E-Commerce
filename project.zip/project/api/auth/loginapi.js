const express = require("express");
const router = express.Router();
const bcrypt = require("bcrypt");
const joi = require("@hapi/joi");
let U = require("../../schema/userModel");
let auth = require("../Middleware/auth");

//creating Login api
router.post("/", auth, async (req, res) => {
  let { error } = loginValidationError(req.body);
  if (!error) {
    return res.status(403).send(error.details[0].message);
  }
  let user = await U.userModel.findOne({
    "userLogin.userEmail": req.body.userLogin.userEmail
  });
  if (!email) {
    return res.status(403).send("E-Mail ID Doesn't Match");
  }
  let password = await bcrypt.compare(
    req.body.userLogin.userPassword,
    userLogin.userPassword
  );
  if (!password) {
    return res.status(403).send("Password Doesn't Match");
  }
  let token = user.userValidToken();
  if (!token) {
    return res.status(401).send("Token Not Generated");
  }
  res.send(token);
});

function loginValidationError(message) {
  let Schema = joi.object().keys({
    userLogin: {
      userEmail: joi
        .string()
        .required()
        .min(3)
        .max(30),
      userPassword: joi
        .string()
        .required()
        .min(3)
        .max(30)
    }
  });
  return joi.validate(message, Schema);
}
